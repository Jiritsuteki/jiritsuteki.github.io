"use client";

import { useEffect, useRef, type CSSProperties } from "react";
import {
  SlatGraph as SlatGraphEngine,
  type ContributionDay,
  type SlatGraphOptions,
} from "../dist/slat-graph.js";

export type {
  ContributionDay,
  HoveredDay,
  SlatGraphOptions,
} from "../dist/slat-graph.js";

export interface SlatGraphProps extends SlatGraphOptions {
  className?: string;
  style?: CSSProperties;
  "aria-label"?: string;
}

const EMPTY_DATA: ContributionDay[] = [];

export function SlatGraph({
  year = 2025,
  data = EMPTY_DATA,
  radius = 100,
  strength = 2,
  speed = 0.7,
  trail = 0.75,
  minWidth = 640,
  paused = false,
  variant = "squares",
  onHover,
  onColorChange,
  className,
  style,
  "aria-label": ariaLabel = "Interactive contribution graph",
}: SlatGraphProps) {
  const hostRef = useRef<HTMLDivElement>(null);
  const graphRef = useRef<SlatGraphEngine | null>(null);
  const callbacksRef = useRef({ onHover, onColorChange });
  callbacksRef.current = { onHover, onColorChange };

  const options = {
    year,
    data,
    radius,
    strength,
    speed,
    trail,
    minWidth,
    paused,
    variant,
  };
  const optionsRef = useRef(options);
  optionsRef.current = options;

  useEffect(() => {
    if (!hostRef.current) return;

    const graph = new SlatGraphEngine(hostRef.current, {
      ...optionsRef.current,
      onHover: (day) => callbacksRef.current.onHover?.(day),
      onColorChange: (value) => callbacksRef.current.onColorChange?.(value),
    });
    graphRef.current = graph;

    return () => {
      graphRef.current = null;
      graph.destroy();
    };
  }, []);

  useEffect(() => {
    graphRef.current?.update({
      year,
      data,
      radius,
      strength,
      speed,
      trail,
      minWidth,
      paused,
      variant,
    });
  }, [year, data, radius, strength, speed, trail, minWidth, paused, variant]);

  return (
    <div
      ref={hostRef}
      className={className}
      aria-label={ariaLabel}
      style={{
        position: "relative",
        width: "100%",
        minHeight: 320,
        aspectRatio: "2.7 / 1",
        ...style,
      }}
    />
  );
}

export default SlatGraph;
