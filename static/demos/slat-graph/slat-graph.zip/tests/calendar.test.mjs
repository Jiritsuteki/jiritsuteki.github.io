import test from "node:test";
import assert from "node:assert/strict";
import { makeCalendar, SlatGraph } from "../dist/slat-graph.js";

for (const [year, expectedDays] of [
  [2025, 365],
  [2024, 366],
  [2028, 366],
  [2100, 365],
  [2000, 366],
]) {
  test(`${year} contains every calendar date once in its correct weekday row`, () => {
    const days = makeCalendar(year);
    const valid = days.filter((day) => day.valid);

    assert.equal(valid.length, expectedDays);
    assert.equal(new Set(valid.map((day) => day.date)).size, expectedDays);
    assert.equal(valid[0].date, `${year}-01-01`);
    assert.equal(valid.at(-1).date, `${year}-12-31`);

    valid.forEach((day, index) => {
      const expected = new Date(Date.UTC(year, 0, 1) + index * 86400000);
      assert.equal(day.date, expected.toISOString().slice(0, 10));
      assert.equal(day.row, expected.getUTCDay());
      assert.ok(Number.isInteger(day.col) && day.col >= 0);
    });

    assert.ok(
      days
        .filter((day) => !day.valid)
        .every((day) => day.date < `${year}-01-01`),
    );
  });
}

test("a leap year starting on Saturday occupies 54 week columns", () => {
  const days = makeCalendar(2028);
  assert.equal(days.at(-1).col + 1, 54);
  assert.equal(days.find((day) => day.date === "2028-01-01").row, 6);
  assert.equal(days.find((day) => day.date === "2028-12-31").col, 53);
  assert.equal(days.find((day) => day.date === "2028-12-31").row, 0);
});

test("duplicate records sum whole nonnegative counts and reject invalid records", () => {
  const days = makeCalendar(2025, [
    { date: "2025-01-01", count: 2.9 },
    { date: "2025-01-01", count: 3.8 },
    { date: "2025-01-01", count: -10 },
    { date: "2025-01-01", count: Infinity },
    { date: "2025-01-01", count: NaN },
    { date: "2025-01-01", count: "8" },
    { date: "2025-01-02", count: -2 },
    { date: "2025-01-03", count: 1 },
    { date: "2025-01-04", count: 3 },
    { date: "2025-01-05", count: 6 },
    { date: "2025-01-06", count: 7 },
    { date: "2025-02-29", count: 99 },
    { date: "2025-02-30", count: 99 },
    { date: "2025-13-01", count: 99 },
    { date: "2025-1-07", count: 99 },
    { date: "2025-01-07T00:00:00Z", count: 99 },
    { date: 20250107, count: 99 },
    null,
  ]).filter((day) => day.valid);

  assert.equal(
    days.reduce((total, day) => total + day.count, 0),
    22,
  );
  assert.deepEqual(
    days.slice(0, 6).map(({ count, level }) => [count, level]),
    [
      [5, 3],
      [0, 0],
      [1, 1],
      [3, 2],
      [6, 3],
      [7, 4],
    ],
  );
  assert.ok(days.every((day) => Number.isFinite(day.count) && day.count >= 0));
});

test("a real leap day accepts contributions and non-array input remains empty", () => {
  const leapDay = makeCalendar(2024, [{ date: "2024-02-29", count: 2 }]).find(
    (day) => day.date === "2024-02-29",
  );
  assert.equal(leapDay.count, 2);
  assert.equal(leapDay.row, 4);
  assert.ok(makeCalendar(2025, null).every((day) => day.count === 0));
  assert.ok(
    makeCalendar(2025, { date: "2025-01-01", count: 8 }).every(
      (day) => day.count === 0,
    ),
  );
});

test("calendar layout keeps square cells aligned and inside its surface", () => {
  for (const width of [320, 640, 1000]) {
    const days = makeCalendar(2028);
    const context = { width, height: 270, days, cols: days.at(-1).col + 1 };
    SlatGraph.prototype.layout.call(context);

    assert.ok(context.cellW > 0);
    assert.equal(context.cellW, context.cellH);
    assert.equal(context.pitch, context.rowPitch);
    assert.equal(days[0].x, days[1].x);
    assert.ok(Math.abs(days[1].y - days[0].y - context.pitch) < 1e-10);
    assert.ok(Math.abs(days[7].x - days[0].x - context.pitch) < 1e-10);
    assert.equal(days[0].y, days[7].y);

    for (const day of days.filter((day) => day.valid)) {
      assert.ok(day.x - context.cellW / 2 >= 0);
      assert.ok(day.x + context.cellW / 2 <= width);
      assert.ok(day.y - context.cellH / 2 >= 0);
      assert.ok(day.y + context.cellH / 2 <= context.height);
    }
  }
});
