import { readFile, writeFile, readdir } from "node:fs/promises";
import { deflateRawSync } from "node:zlib";
const root = new URL("./", import.meta.url);
export const files = [
  "README.md",
  "LICENSE",
  "package.json",
  "serve.mjs",
  "package.mjs",
  "export.mjs",
  ".gitignore",
  ".gitattributes",
  ".editorconfig",
];
async function collect(dir) {
  for (const file of await readdir(new URL(dir + "/", root), {
    withFileTypes: true,
  })) {
    const name = dir + "/" + file.name;
    if (file.isDirectory()) await collect(name);
    else if (/\.(js|mjs|ts|tsx|html|css|yml|jpg|png)$/.test(file.name))
      files.push(name);
  }
}
for (const dir of ["dist", "integration", "tests", ".github", "assets"])
  await collect(dir);
const crcTable = Uint32Array.from({ length: 256 }, (_, n) => {
  for (let i = 0; i < 8; i++) n = n & 1 ? 0xedb88320 ^ (n >>> 1) : n >>> 1;
  return n >>> 0;
});
function crc32(data) {
  let crc = 0xffffffff;
  for (const byte of data) crc = crcTable[(crc ^ byte) & 255] ^ (crc >>> 8);
  return (crc ^ 0xffffffff) >>> 0;
}
const locals = [],
  central = [];
let offset = 0;
for (const file of files.sort()) {
  const name = Buffer.from(file);
  const data = await readFile(new URL(file, root));
  const compressed = deflateRawSync(data);
  const crc = crc32(data);
  const local = Buffer.alloc(30);
  local.writeUInt32LE(0x04034b50);
  local.writeUInt16LE(20, 4);
  local.writeUInt16LE(0x0800, 6);
  local.writeUInt16LE(8, 8);
  local.writeUInt16LE(0x5d5c, 12);
  local.writeUInt32LE(crc, 14);
  local.writeUInt32LE(compressed.length, 18);
  local.writeUInt32LE(data.length, 22);
  local.writeUInt16LE(name.length, 26);
  const dir = Buffer.alloc(46);
  dir.writeUInt32LE(0x02014b50);
  dir.writeUInt16LE(20, 4);
  dir.writeUInt16LE(20, 6);
  dir.writeUInt16LE(0x0800, 8);
  dir.writeUInt16LE(8, 10);
  dir.writeUInt16LE(0x5d5c, 14);
  dir.writeUInt32LE(crc, 16);
  dir.writeUInt32LE(compressed.length, 20);
  dir.writeUInt32LE(data.length, 24);
  dir.writeUInt16LE(name.length, 28);
  dir.writeUInt32LE(offset, 42);
  locals.push(local, name, compressed);
  central.push(dir, name);
  offset += local.length + name.length + compressed.length;
}
const directory = Buffer.concat(central);
const end = Buffer.alloc(22);
end.writeUInt32LE(0x06054b50);
end.writeUInt16LE(files.length, 8);
end.writeUInt16LE(files.length, 10);
end.writeUInt32LE(directory.length, 12);
end.writeUInt32LE(offset, 16);
await writeFile(
  new URL("dist/slat-graph.zip", root),
  Buffer.concat([...locals, directory, end]),
);
console.log(
  `Source package ready: dist/slat-graph.zip (${files.length} files)`,
);
