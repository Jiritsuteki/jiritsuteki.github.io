import { mkdir, copyFile, stat } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import path from "node:path";
import { files } from "./package.mjs";

const root = path.dirname(fileURLToPath(import.meta.url));
const defaultDestination = path.resolve(root, "..", "slat-graph-github");
const destination = path.resolve(
  process.argv[2] ||
    (defaultDestination === root ? root + "-export" : defaultDestination),
);

if (destination === root || destination.startsWith(root + path.sep)) {
  throw new Error("Choose a destination outside the project directory.");
}

const existing = await stat(destination).catch((error) => {
  if (error.code === "ENOENT") return null;
  throw error;
});
if (existing)
  throw new Error("Destination already exists. Choose a new directory.");

await mkdir(destination, { recursive: true });
for (const file of [...files, "dist/slat-graph.zip"]) {
  const target = path.join(destination, file);
  await mkdir(path.dirname(target), { recursive: true });
  await copyFile(path.join(root, file), target);
}
console.log(`GitHub source ready: ${destination}`);
