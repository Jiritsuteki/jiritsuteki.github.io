# Slat Graph

A dependency-free canvas contribution grid with a mouse-following effect. Rounded squares stay gray in empty areas and blend into green near active days. The interface uses neutral colors; green belongs to contributions and the local effect.

The demo uses sample data, not a live GitHub connection. The standalone engine works with vanilla JavaScript; a React / Next.js wrapper is included.

![Slat Graph preview](assets/preview.jpg)

## Run locally

Requires Node.js 20 or later. No dependencies to install.

```sh
npm run dev
```

Open the local URL printed in the terminal. Use the local server rather than opening the HTML file directly.

```sh
npm test
npm run check
npm run package
npm run export
```

These commands run the calendar tests, check JavaScript syntax, create `dist/slat-graph.zip`, and export a clean repository to a sibling folder.

The export has no Git history or hosting-specific configuration. It will not overwrite an existing directory. To choose a different destination, use `npm run export -- ../my-copy`.

From the exported folder, start your repository with:

```sh
git init -b main
git add .
git commit -m "Initial release"
```

Then connect your GitHub repository and push it.

## Vanilla JavaScript

Copy `dist/slat-graph.js` into your project. Keep `dist/slat-graph.d.ts` alongside it for TypeScript support.

```html
<div id="graph" style="position:relative; min-height:320px; aspect-ratio:2.7 / 1"></div>

<script type="module">
  import { SlatGraph } from "./dist/slat-graph.js";

  const graph = new SlatGraph(document.querySelector("#graph"), {
    year: 2025,
    data: [
      { date: "2025-04-02", count: 1 },
      { date: "2025-05-11", count: 6 },
      { date: "2025-06-30", count: 1 },
    ],
  });
</script>
```

Use `graph.update({ ... })` for partial option updates and `graph.destroy()` when removing the graph. Pass a new array when updating data; `graph.update({ data: [] })` clears it.

The canvas follows its container size. A minimum height of `320px` and aspect ratio of `2.7 / 1` work well on desktop. Narrow containers scroll horizontally at the configured `minWidth`.

## React / Next.js

Copy `integration/SlatGraph.tsx` and both engine files into your project, keeping their relative paths. React is supplied by your app. The wrapper includes `"use client"`, updates the existing engine when props change, and cleans it up on unmount.

```tsx
import SlatGraph, { type ContributionDay } from "./integration/SlatGraph";

const data: ContributionDay[] = [
  { date: "2025-04-02", count: 1 },
  { date: "2025-05-11", count: 6 },
  { date: "2025-06-30", count: 1 },
];

export default function Contributions() {
  return <SlatGraph year={2025} data={data} />;
}
```

Animation runs through `requestAnimationFrame` without React renders on every frame. The engine respects reduced motion and pauses when offscreen. Arrow keys navigate days; Escape clears the selection. A text summary is available to assistive technology.

## Data and options

Each record has a `date` in `YYYY-MM-DD` format and a nonnegative integer `count`. Missing days are zero. Duplicate dates are summed; invalid records and dates outside the selected year are not displayed. Live GitHub fetching is left to your app. Keep access tokens on your server.

| Option | Default | Purpose |
| --- | --- | --- |
| `year` | `2025` | Calendar year. |
| `data` | `[]` | Array of `{ date, count }` records. |
| `radius` | `100` | Effect radius. |
| `strength` | `2` | Effect intensity, from `0` to `2`. |
| `speed` | `0.7` | Animation speed. |
| `trail` | `0.75` | Trail softness, from `0.5` to `1`. |
| `minWidth` | `640` | Minimum canvas width in pixels. |
| `paused` | `false` | Pause continuous animation. |
| `variant` | `"squares"` | `"squares"` or `"slats"`. |
| `onHover` | — | Receives the hovered day or `null`. |
| `onColorChange` | — | Receives `{ mix, color }` as the local color changes. |

The wrapper also accepts `className`, `style`, and `aria-label`.

## GitHub Pages

Push the exported folder to your repository. Under **Settings → Pages**, set the source to **GitHub Actions**, then run the manual [Pages workflow](.github/workflows/pages.yml) from **Actions**. The workflow publishes the demo from `dist`.

## Attribution and license

Inspired by [React Bits Micro Slats](https://reactbits.dev/backgrounds/micro-slats) and GitHub's contribution grid. This is an independent implementation; it does not include React Bits source code.

[MIT](LICENSE).
